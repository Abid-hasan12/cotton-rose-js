import { company } from "@/data/company";

export const dynamic = "force-static";

export default function robots() {
  return { rules: { userAgent: "*", allow: "/", disallow: ["/api/"] }, sitemap: `${company.website}/sitemap.xml` };
}
