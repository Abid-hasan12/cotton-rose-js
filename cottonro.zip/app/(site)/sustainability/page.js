import { redirect } from "next/navigation";
export default function Page() { redirect("/quality-compliance"); }
