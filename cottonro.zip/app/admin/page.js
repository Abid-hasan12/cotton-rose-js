"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

const statusOptions = ["Pending", "Contacted", "Closed"];

export default function AdminDashboardPage() {
  const router = useRouter();
  const [inquiries, setInquiries] = useState([]);
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState(null);
  const [message, setMessage] = useState("");

  async function loadInquiries() {
    const response = await fetch("/api/admin/inquiries");
    if (response.status === 401) return router.replace("/admin/login");
    const result = await response.json();
    if (!response.ok) throw new Error(result.message || "Could not load inquiries.");
    setInquiries(result);
  }

  useEffect(() => {
    loadInquiries().catch((error) => setMessage(error.message));
  }, []);

  const visible = useMemo(() => filter === "All" ? inquiries : inquiries.filter((inquiry) => inquiry.status === filter), [filter, inquiries]);
  const pendingCount = inquiries.filter((inquiry) => inquiry.status === "Pending").length;

  async function updateStatus(id, status) {
    const response = await fetch("/api/admin/inquiries", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id, status }) });
    if (response.status === 401) return router.replace("/admin/login");
    if (!response.ok) {
      const result = await response.json();
      setMessage(result.message || "Could not update inquiry.");
      return;
    }
    setInquiries((current) => current.map((inquiry) => inquiry.id === id ? { ...inquiry, status } : inquiry));
    setSelected((current) => current?.id === id ? { ...current, status } : current);
  }

  async function removeInquiry(id) {
    if (!window.confirm("Delete this inquiry permanently?")) return;
    const response = await fetch(`/api/admin/inquiries?id=${id}`, { method: "DELETE" });
    if (!response.ok) {
      const result = await response.json();
      setMessage(result.message || "Could not delete inquiry.");
      return;
    }
    setInquiries((current) => current.filter((inquiry) => inquiry.id !== id));
    setSelected(null);
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace("/admin/login");
  }

  return (
    <main className="admin-shell">
      <header className="admin-header">
        <div><p className="section-label">CottonRose</p><h1>Inquiry dashboard</h1></div>
        <button className="admin-link-button" onClick={logout}>Log out</button>
      </header>
      <section className="admin-stats">
        <div><span>Total inquiries</span><strong>{inquiries.length}</strong></div>
        <div><span>Pending follow-up</span><strong>{pendingCount}</strong></div>
      </section>
      {message && <p className="admin-alert" role="alert">{message}</p>}
      <section className="admin-panel">
        <div className="admin-toolbar"><h2>Recent inquiries</h2><label>Filter <select value={filter} onChange={(event) => setFilter(event.target.value)}><option>All</option>{statusOptions.map((status) => <option key={status}>{status}</option>)}</select></label></div>
        {visible.length === 0 ? <p className="admin-muted">No inquiries match this filter.</p> : <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>Received</th><th>Name</th><th>Product</th><th>Contact</th><th>Status</th><th /></tr></thead><tbody>{visible.map((inquiry) => <tr key={inquiry.id}><td>{new Date(inquiry.created_at).toLocaleString()}</td><td><button className="admin-name" onClick={() => setSelected(inquiry)}>{inquiry.name}</button></td><td>{inquiry.product}</td><td><a href={`mailto:${inquiry.email}`}>{inquiry.email}</a><br />{inquiry.phone}</td><td><select className={`admin-status admin-status--${inquiry.status.toLowerCase()}`} value={inquiry.status} onChange={(event) => updateStatus(inquiry.id, event.target.value)}>{statusOptions.map((status) => <option key={status}>{status}</option>)}</select></td><td><button className="admin-delete" onClick={() => removeInquiry(inquiry.id)}>Delete</button></td></tr>)}</tbody></table></div>}
      </section>
      {selected && <div className="admin-modal-backdrop" role="presentation" onClick={() => setSelected(null)}><section className="admin-modal" role="dialog" aria-modal="true" aria-labelledby="inquiry-title" onClick={(event) => event.stopPropagation()}><button className="admin-modal__close" onClick={() => setSelected(null)} aria-label="Close inquiry">×</button><p className="section-label">Inquiry #{selected.id}</p><h2 id="inquiry-title">{selected.name}</h2><p className="admin-muted">{selected.email} · {selected.phone}</p><dl className="admin-details"><dt>Product</dt><dd>{selected.product}</dd><dt>Received</dt><dd>{new Date(selected.created_at).toLocaleString()}</dd><dt>Message</dt><dd>{selected.message}</dd></dl><select className="admin-status" value={selected.status} onChange={(event) => updateStatus(selected.id, event.target.value)}>{statusOptions.map((status) => <option key={status}>{status}</option>)}</select></section></div>}
    </main>
  );
}
